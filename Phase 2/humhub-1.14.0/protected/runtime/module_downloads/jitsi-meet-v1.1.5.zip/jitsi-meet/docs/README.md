# Jitsi Meet

Secure, fully featured, and completely free video conferencing.

Jitsi Meet is a fully encrypted, 100% open source video conferencing solution that you can use all day, every day, for free — with no account needed.

- No client software necessary, just pick a name for your room and you are ready to go
- Contacts can join via Brower or dial in via phone
- Screensharing makes your presentation easy
- Use the official Jitsi server or use your own for additional privacy

See (https://meet.jit.si/) for more details.