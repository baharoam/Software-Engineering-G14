Changelog
=========

1.1.5 (May 6, 2022)
-------------------
- Fix #30: Fix rooms loading


1.1.4 (April 18, 2022)
----------------------
- Fix #27: Fix assets on updating of disabled module


1.1.3 (April 14, 2022)
----------------------
- Enh: Disable Guest Access - Do not show menu item to users which are not logged in.


1.1.2 (September 12, 2020)
--------------------------
- Fix #10: Workaround for broken "open in app" link on Android devices
- Fix #11: Authentication failed with Jitsi Password


1.1.0 (April 05, 2020)
----------------------
- Enh #2: Add JWT authentication (thanks to @edmw)
- Fix #4: Added nonce to inline scripts


1.0.0 (March 22, 2020)
----------------------
Initial release
