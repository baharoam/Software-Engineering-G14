<?php
return array (
  'Calendars' => '',
  'Defaults' => '',
  'Event Types' => '',
  'Menu' => 'תפריט',
  'Snippet' => '',
);
