<?php
return array (
  'Allows the user to create new calendar entries' => 'Позволить пользователю создавать новые записи в календаре',
  'Allows the user to edit/delete existing calendar entries' => 'Позволить пользователю редактировать/удалять записи в календаре',
  'Create entry' => 'Создать запись',
  'Manage entries' => 'Управление записями',
);
