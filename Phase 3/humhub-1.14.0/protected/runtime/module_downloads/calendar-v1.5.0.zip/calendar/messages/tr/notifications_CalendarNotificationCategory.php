<?php
return array (
  'Calendar' => 'Takvim',
  'Receive Calendar related Notifications.' => 'Takvim ile ilgili Bildirimler alın.',
);
