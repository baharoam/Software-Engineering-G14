<?php
return array (
  'Calendars' => '',
  'Defaults' => 'По-умолчанию',
  'Event Types' => '',
  'Menu' => 'Меню',
  'Snippet' => '',
);
