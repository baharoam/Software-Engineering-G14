<?php

return [
    'Participants' => 'Uczestnicy',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
