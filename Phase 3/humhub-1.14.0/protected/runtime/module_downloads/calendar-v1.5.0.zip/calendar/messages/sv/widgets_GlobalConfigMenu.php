<?php
return array (
  'Calendars' => 'Kalendrar',
  'Defaults' => 'Standardinställning',
  'Event Types' => 'Aktivitetstyper',
  'Menu' => 'Meny',
  'Snippet' => 'Snippet',
);
