<?php
return array (
  'Calendars' => '',
  'Defaults' => '',
  'Event Types' => '',
  'Menu' => 'القائمة',
  'Snippet' => '',
);
