<?php

return [
    'Participants' => 'مشارکت‌کننده‌ها',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
