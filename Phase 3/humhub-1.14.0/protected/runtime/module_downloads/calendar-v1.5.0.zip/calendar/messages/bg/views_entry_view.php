<?php
return array (
  'Additional information' => 'Допълнителна информация',
  'All' => 'Всички',
  'Attend' => 'Присъствам',
  'Decline' => 'Отказвам',
  'Filter' => 'Филтър',
  'Maybe' => 'Не съм сигурен',
  'Participants' => 'Участници',
  'You are invited, please select your role:' => '',
);
