<?php

return [
    'Full calendar' => '',
    'Participation' => '',
    'Reminder' => '',
];
