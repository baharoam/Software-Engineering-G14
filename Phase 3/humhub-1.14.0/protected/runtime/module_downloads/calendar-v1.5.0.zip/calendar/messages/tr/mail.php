<?php
return array (
  '<strong>Starting</strong> {date}' => '',
  'Additional information:' => 'Ek bilgi:',
  'Location:' => 'Konum:',
  'Organized by {userName}' => '{userName} Tarafından düzenlendi',
  'View Online: {url}' => '',
);
