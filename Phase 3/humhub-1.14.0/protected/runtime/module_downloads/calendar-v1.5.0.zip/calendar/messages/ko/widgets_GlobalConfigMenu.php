<?php
return array (
  'Calendars' => '',
  'Defaults' => '',
  'Event Types' => '',
  'Menu' => '메뉴',
  'Snippet' => '',
);
