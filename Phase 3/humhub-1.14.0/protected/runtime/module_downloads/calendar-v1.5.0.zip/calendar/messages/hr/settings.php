<?php

return [
    'Participation' => 'Sudjelovanje',
    'Reminder' => 'Podsjetnik',
    'Full calendar' => '',
];
