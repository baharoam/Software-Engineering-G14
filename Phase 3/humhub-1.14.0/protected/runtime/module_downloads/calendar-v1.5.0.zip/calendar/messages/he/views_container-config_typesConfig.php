<?php

return [
    '<strong>Create</strong> new event type' => '',
    '<strong>Edit</strong> calendar' => '',
    '<strong>Edit</strong> event type' => '',
];
