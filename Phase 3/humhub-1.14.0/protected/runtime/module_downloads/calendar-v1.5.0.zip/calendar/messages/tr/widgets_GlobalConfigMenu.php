<?php
return array (
  'Calendars' => '',
  'Defaults' => 'Varsayılan',
  'Event Types' => 'Etkinlik Türleri',
  'Menu' => 'Menü',
  'Snippet' => '',
);
