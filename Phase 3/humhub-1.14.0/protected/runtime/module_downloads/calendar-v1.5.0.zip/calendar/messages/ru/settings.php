<?php
return array (
  'Full calendar' => '',
  'Participation' => '',
  'Reminder' => 'Напоминание',
);
