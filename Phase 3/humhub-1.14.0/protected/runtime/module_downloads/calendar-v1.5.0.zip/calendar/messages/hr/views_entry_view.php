<?php
return array (
  'Additional information' => 'Dodatne informacije',
  'All' => 'Sve',
  'Attend' => 'Prisustvo',
  'Decline' => 'Odbij',
  'Filter' => 'Filter',
  'Maybe' => 'Možda',
  'Participants' => 'Sudionici',
  'You are invited, please select your role:' => '',
);
