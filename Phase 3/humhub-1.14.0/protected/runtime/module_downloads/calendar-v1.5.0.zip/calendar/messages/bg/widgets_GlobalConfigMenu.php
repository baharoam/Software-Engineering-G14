<?php
return array (
  'Calendars' => 'Календари',
  'Defaults' => 'По подразбиране',
  'Event Types' => 'Типове събития',
  'Menu' => 'Меню',
  'Snippet' => 'Фрагмент',
);
