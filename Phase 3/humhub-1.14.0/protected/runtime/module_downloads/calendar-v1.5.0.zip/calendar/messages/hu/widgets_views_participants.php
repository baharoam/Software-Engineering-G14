<?php
return array (
  ':count Attending' => ':count Részt vesz',
  ':count Declined' => ':count Elutasítva',
  ':count Invited' => ':count Meghívva',
  ':count Undecided' => ':count Még nem döntött',
  'Participants' => 'Résztvevők',
);
