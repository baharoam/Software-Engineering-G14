<?php
return array (
  'Calendars' => '',
  'Defaults' => 'مقادیر پیش‌فرض',
  'Event Types' => '',
  'Menu' => 'منو',
  'Snippet' => '',
);
