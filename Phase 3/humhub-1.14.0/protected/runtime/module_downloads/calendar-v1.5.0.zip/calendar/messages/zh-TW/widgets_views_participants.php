<?php
return array (
  ':count Attending' => '',
  ':count Declined' => '',
  ':count Invited' => '',
  ':count Undecided' => '',
  'Participants' => '參與者',
);
