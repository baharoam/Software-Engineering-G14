<?php
return array (
  'Day' => '',
  'List' => 'Список',
  'Month' => '',
  'Today' => 'Сегодня',
  'Week' => '',
  'Year' => '',
);
