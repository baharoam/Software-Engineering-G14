<?php
return array (
  'Day' => 'Gün',
  'List' => 'Liste',
  'Month' => 'Ay',
  'Today' => '',
  'Week' => 'Hafta',
  'Year' => 'Yıl',
);
