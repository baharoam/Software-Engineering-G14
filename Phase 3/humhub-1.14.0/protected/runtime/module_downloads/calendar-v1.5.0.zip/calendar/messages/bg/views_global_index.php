<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Филтриране</strong> на събития',
  '<strong>Select</strong> calendars' => '<strong>Изберете</strong> календари',
  'Followed spaces' => 'Следвани раздели',
  'Followed users' => 'Следвани потребители',
  'I\'m attending' => 'Посещавам',
  'My events' => 'Моите Събития',
  'My profile' => 'Моят Профил',
  'My spaces' => 'Моите Раздели',
);
