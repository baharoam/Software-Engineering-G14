<?php
return array (
  'Calendar' => 'Kalender',
  'Receive Calendar related Notifications.' => 'Ta emot kalenderrelaterade aviseringar.',
);
