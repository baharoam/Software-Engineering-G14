<?php
return array (
  ':count Attending' => ':count Närvarar',
  ':count Declined' => ':count har avböjt',
  ':count Invited' => ':count Inbjudna',
  ':count Undecided' => ':count Osäkra',
  'Participants' => 'Deltagare',
);
