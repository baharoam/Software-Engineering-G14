<?php
return array (
  'Day' => '',
  'List' => 'فهرست',
  'Month' => '',
  'Today' => '',
  'Week' => '',
  'Year' => '',
);
