<?php
return array (
  'Day' => 'Dan',
  'List' => 'Lista',
  'Month' => 'Mjesec',
  'Today' => 'Danas',
  'Week' => 'Sedmica',
  'Year' => 'Godina',
);
