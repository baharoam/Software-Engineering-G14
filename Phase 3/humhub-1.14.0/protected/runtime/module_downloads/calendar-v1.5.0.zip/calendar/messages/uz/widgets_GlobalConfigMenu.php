<?php

return [
    'Calendars' => '',
    'Defaults' => '',
    'Event Types' => '',
    'Menu' => '',
    'Snippet' => '',
];
