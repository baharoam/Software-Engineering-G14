<?php
return array (
  'Additional information' => 'Ytterligare information',
  'All' => 'Alla',
  'Attend' => 'Deltar',
  'Decline' => 'Avböj',
  'Filter' => 'Filtrera',
  'Maybe' => 'Kanske',
  'Participants' => 'Deltagare',
  'You are invited, please select your role:' => 'Du är inbjuden, välj din roll:',
);
