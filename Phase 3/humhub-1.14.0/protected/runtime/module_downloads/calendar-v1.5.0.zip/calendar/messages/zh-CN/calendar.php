<?php
return array (
  'Day' => '',
  'List' => '列表',
  'Month' => '',
  'Today' => '',
  'Week' => '',
  'Year' => '',
);
