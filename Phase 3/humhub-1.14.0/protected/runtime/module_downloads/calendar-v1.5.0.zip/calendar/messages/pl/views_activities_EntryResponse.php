<?php

return [
    '%displayName% cannot attend %contentTitle%.' => '%displayName% nie może uczestniczyć w %contentTitle%.',
    '%displayName% is attending %contentTitle%.' => '%displayName% uczestniczy w %contentTitle%.',
    '%displayName% might be attending %contentTitle%.' => '%displayName% może weźmie udział w %contentTitle%.',
    '%displayName% is invited to %contentTitle%.' => '',
];
