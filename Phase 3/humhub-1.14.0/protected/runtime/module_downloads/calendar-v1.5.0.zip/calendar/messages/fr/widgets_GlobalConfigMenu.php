<?php
return array (
  'Calendars' => 'Calendriers',
  'Defaults' => 'Général',
  'Event Types' => 'Types',
  'Menu' => 'Menu',
  'Snippet' => 'Extrait',
);
