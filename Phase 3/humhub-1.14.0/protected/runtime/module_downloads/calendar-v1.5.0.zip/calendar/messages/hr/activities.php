<?php

return [
    'Calendar: Invite' => '',
    'Calendar: attend' => '',
    'Calendar: decline' => '',
    'Calendar: maybe' => '',
    'Whenever someone declines to participate in an event.' => '',
    'Whenever someone invites to participate in an event.' => '',
    'Whenever someone may be participating in an event.' => '',
    'Whenever someone participates in an event.' => '',
];
