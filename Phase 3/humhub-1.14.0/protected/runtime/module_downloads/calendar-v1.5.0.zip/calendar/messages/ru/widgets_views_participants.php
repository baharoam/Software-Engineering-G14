<?php

return [
    'Participants' => 'Участники',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
