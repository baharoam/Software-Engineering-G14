<?php
return array (
  'Calendars' => '',
  'Defaults' => 'Oletukset',
  'Event Types' => 'Taphtumatyypit',
  'Menu' => 'Valikko',
  'Snippet' => 'Laatikko',
);
