<?php
return array (
  'Additional information' => 'További információ',
  'All' => 'Minden',
  'Attend' => 'Részt vesz',
  'Decline' => 'Nem vesz részt',
  'Filter' => 'Szűrés',
  'Maybe' => 'Talán',
  'Participants' => 'Résztvevők',
  'You are invited, please select your role:' => 'Önt meghívták, kérjük, válassza ki a szerepét:',
);
