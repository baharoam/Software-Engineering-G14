<?php
return array (
  'Full calendar' => 'Calendario completo',
  'Participation' => 'Partecipazione',
  'Reminder' => 'Promemoria',
);
