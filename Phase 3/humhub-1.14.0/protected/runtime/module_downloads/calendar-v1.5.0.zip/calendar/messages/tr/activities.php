<?php

return [
    'Calendar: attend' => 'Takvim: katılmak',
    'Calendar: decline' => 'Takvim: reddetmek',
    'Calendar: maybe' => 'Takvim: belki',
    'Whenever someone declines to participate in an event.' => 'Birisi bir etkinliğe katılmayı reddettiğinde.',
    'Whenever someone may be participating in an event.' => 'Birisi ne zaman bir etkinliğe katılabilir.',
    'Whenever someone participates in an event.' => 'Birisi bir etkinliğe katıldığında.',
    'Calendar: Invite' => '',
    'Whenever someone invites to participate in an event.' => '',
];
