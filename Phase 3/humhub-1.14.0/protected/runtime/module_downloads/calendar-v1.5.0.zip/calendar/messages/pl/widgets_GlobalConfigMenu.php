<?php
return array (
  'Calendars' => 'Kalendarze',
  'Defaults' => 'Domyślne',
  'Event Types' => 'Typy wydarzeń',
  'Menu' => 'Menu',
  'Snippet' => 'Panel',
);
