<?php
return array (
  ':count Attending' => ':count participent',
  ':count Declined' => ':count ont décliné',
  ':count Invited' => ':count sont invité·es',
  ':count Undecided' => ':count ne savent pas encore',
  'Participants' => 'Participant·es',
);
