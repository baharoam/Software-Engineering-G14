<?php

return [
    '<strong>Upcoming</strong> events ' => '',
    'Open Calendar' => '',
];
