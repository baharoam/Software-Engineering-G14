<?php
return array (
  'Additional information' => '',
  'All' => 'Все',
  'Attend' => 'Посетить',
  'Decline' => 'Отказать',
  'Filter' => 'Фильтр',
  'Maybe' => 'Возможно',
  'Participants' => 'Участники',
  'You are invited, please select your role:' => '',
);
