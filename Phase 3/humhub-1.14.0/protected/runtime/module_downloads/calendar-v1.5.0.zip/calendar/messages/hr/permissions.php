<?php
return array (
  'Allows the user to create new calendar entries' => 'Korisniku omogućuje stvaranje novih unosa u kalendar',
  'Allows the user to edit/delete existing calendar entries' => 'Korisniku omogućuje uređivanje / brisanje postojećih unosa u kalendar',
  'Create entry' => 'Kreriaj unos',
  'Manage entries' => 'Upravljaj unosima',
);
