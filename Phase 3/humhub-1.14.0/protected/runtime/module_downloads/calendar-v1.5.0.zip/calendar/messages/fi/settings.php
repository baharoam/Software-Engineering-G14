<?php

return [
    'Participation' => 'osallistujat',
    'Reminder' => 'Muistutus',
    'Full calendar' => '',
];
