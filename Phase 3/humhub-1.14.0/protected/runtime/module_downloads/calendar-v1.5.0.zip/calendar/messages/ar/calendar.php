<?php
return array (
  'Day' => '',
  'List' => 'قائمة',
  'Month' => '',
  'Today' => '',
  'Week' => '',
  'Year' => '',
);
