<?php
return array (
  'Day' => '',
  'List' => '清單',
  'Month' => '',
  'Today' => '',
  'Week' => '',
  'Year' => '',
);
