<?php
return array (
  'Day' => '',
  'List' => 'Liste',
  'Month' => '',
  'Today' => '',
  'Week' => '',
  'Year' => '',
);
