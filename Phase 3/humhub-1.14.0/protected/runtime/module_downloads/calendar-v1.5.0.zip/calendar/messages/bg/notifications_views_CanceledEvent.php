<?php

return [
    '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} анулира събитие "{contentTitle}" в раздела {spaceName}.',
    '{displayName} canceled event "{contentTitle}".' => '{displayName} отмени събитие "{contentTitle}".',
    '{displayName} just added you to event "{contentTitle}".' => '{displayName} току-що ви добави към събитие "{contentTitle}".',
    '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} току-що актуализира събитие "{contentTitle}" в раздел {spaceName}.',
    '{displayName} just updated event {contentTitle}.' => '{displayName} току-що актуализира събитие {contentTitle}.',
    '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} отвори отново събитие "{contentTitle}" в раздел {spaceName}.',
    '{displayName} reopened event "{contentTitle}".' => '{displayName} отвори отново събитие "{contentTitle}".',
    '{displayName} just invited you to event "{contentTitle}".' => '',
];
