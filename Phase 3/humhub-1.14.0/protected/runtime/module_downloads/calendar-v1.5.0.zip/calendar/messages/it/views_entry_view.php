<?php
return array (
  'Additional information' => 'Informazioni aggiuntive',
  'All' => 'Tutti',
  'Attend' => 'Partecipa',
  'Decline' => 'Rifiuta',
  'Filter' => 'Filtro',
  'Maybe' => 'Forse',
  'Participants' => 'Partecipanti',
  'You are invited, please select your role:' => 'Sei invitato, seleziona il tuo ruolo:',
);
