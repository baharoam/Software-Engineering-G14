<?php
return array (
  'Additional information' => '',
  'All' => 'همه',
  'Attend' => 'حضور',
  'Decline' => 'انصراف',
  'Filter' => 'پالایه',
  'Maybe' => 'احتمالا',
  'Participants' => 'مشارکت‌کننده‌ها',
  'You are invited, please select your role:' => '',
);
