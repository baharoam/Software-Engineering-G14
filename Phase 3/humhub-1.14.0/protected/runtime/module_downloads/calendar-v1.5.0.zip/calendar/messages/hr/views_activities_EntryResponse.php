<?php

return [
    '%displayName% cannot attend %contentTitle%.' => '%displayName% ne može prisustvovati %contentTitle%.',
    '%displayName% is attending %contentTitle%.' => '%displayName% prisustvuje %contentTitle%.',
    '%displayName% might be attending %contentTitle%.' => '%displayName% možda će prisustvovati %contentTitle%.',
    '%displayName% is invited to %contentTitle%.' => '',
];
