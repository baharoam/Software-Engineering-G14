<?php
return array (
  'Additional information' => '',
  'All' => 'Kaikki',
  'Attend' => 'Osallistu',
  'Decline' => 'En osallistu',
  'Filter' => 'Suodatin',
  'Maybe' => 'Ehkä osalistun',
  'Participants' => 'Osallistujat',
  'You are invited, please select your role:' => '',
);
