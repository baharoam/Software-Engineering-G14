<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Стартираща</strong> {date}',
  'Additional information:' => 'Допълнителна информация:',
  'Location:' => 'Локация:',
  'Organized by {userName}' => 'Организирано от {userName}',
  'View Online: {url}' => 'Преглед онлайн: {url}',
);
