<?php
return array (
  'Calendar' => 'Kalendarz',
  'Receive Calendar related Notifications.' => 'Otrzymuj powiadomienia związane z kalendarzem.',
);
