<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Kreiraj</strong> novi tip događaja',
  '<strong>Edit</strong> calendar' => '<strong>Uredi</strong> kalendar',
  '<strong>Edit</strong> event type' => '<strong>Uredi</strong> tip događaja',
);
