<?php
return array (
  'Full calendar' => 'Fullständig kalender',
  'Participation' => 'Deltagande',
  'Reminder' => 'Påminnelse',
);
