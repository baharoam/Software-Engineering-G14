<?php
return array (
  'Calendars' => '',
  'Defaults' => '',
  'Event Types' => '',
  'Menu' => '選單',
  'Snippet' => '',
);
