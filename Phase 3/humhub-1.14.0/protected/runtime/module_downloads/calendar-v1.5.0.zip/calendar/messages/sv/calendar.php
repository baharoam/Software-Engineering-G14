<?php
return array (
  'Day' => 'Dag',
  'List' => 'Lista',
  'Month' => 'Månad',
  'Today' => 'I dag',
  'Week' => 'Vecka',
  'Year' => 'År',
);
