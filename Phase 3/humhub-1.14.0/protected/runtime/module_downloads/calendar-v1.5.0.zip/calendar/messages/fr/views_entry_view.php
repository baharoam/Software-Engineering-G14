<?php
return array (
  'Additional information' => 'Informations additionnelles :',
  'All' => 'Tous et toutes',
  'Attend' => 'Participer',
  'Decline' => 'Décliner',
  'Filter' => 'Filtre',
  'Maybe' => 'Peut-être',
  'Participants' => 'Participant·es',
  'You are invited, please select your role:' => 'Vous êtes invité·e, veuillez sélectionner votre rôle :',
);
