<?php
return array (
  'Day' => '',
  'List' => '리스트',
  'Month' => '',
  'Today' => '',
  'Week' => '',
  'Year' => '',
);
