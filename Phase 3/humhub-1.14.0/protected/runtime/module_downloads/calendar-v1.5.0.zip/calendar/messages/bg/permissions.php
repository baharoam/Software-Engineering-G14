<?php
return array (
  'Allows the user to create new calendar entries' => 'Позволява на потребителя да създава нови записи в календара',
  'Allows the user to edit/delete existing calendar entries' => 'Позволява на потребителя да редактира / изтрива съществуващи записи в календара',
  'Create entry' => 'Създаване на запис',
  'Manage entries' => 'Управление на записи',
);
