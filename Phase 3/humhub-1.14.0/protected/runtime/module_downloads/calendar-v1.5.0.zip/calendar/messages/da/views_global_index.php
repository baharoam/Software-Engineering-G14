<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filter</strong> events',
  '<strong>Select</strong> calendars' => '<strong>Vælg</strong> Kalendere',
  'Followed spaces' => 'Fulgte sider',
  'Followed users' => 'Fulgte brugere',
  'I\'m attending' => 'Jeg deltager',
  'My events' => 'Mine events',
  'My profile' => 'Min profil',
  'My spaces' => 'Mine Sider',
);
