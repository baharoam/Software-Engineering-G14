<?php
return array (
  'Calendars' => 'Kalendari',
  'Defaults' => 'Zadano',
  'Event Types' => 'Vrste događaja',
  'Menu' => 'Izbornik',
  'Snippet' => 'Isječak',
);
