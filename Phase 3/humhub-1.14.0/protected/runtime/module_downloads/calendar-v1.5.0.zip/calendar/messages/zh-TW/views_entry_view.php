<?php
return array (
  'Additional information' => '',
  'All' => '所有結果',
  'Attend' => '',
  'Decline' => '拒絕',
  'Filter' => '篩選條件',
  'Maybe' => '',
  'Participants' => '參與者',
  'You are invited, please select your role:' => '',
);
