<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrera</strong> aktiviteter',
  '<strong>Select</strong> calendars' => '<strong>Välj</strong> kalender',
  'Followed spaces' => 'Följda forum',
  'Followed users' => 'Följda användare',
  'I\'m attending' => 'Jag deltar',
  'My events' => 'Mina aktiviteter',
  'My profile' => 'Min profil',
  'My spaces' => 'Mina forum',
);
