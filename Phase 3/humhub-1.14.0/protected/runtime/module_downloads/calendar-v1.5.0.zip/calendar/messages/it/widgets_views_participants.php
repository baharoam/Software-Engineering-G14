<?php
return array (
  ':count Attending' => ':count Partecipanti',
  ':count Declined' => ':count Rifiutati',
  ':count Invited' => ':count Invitati',
  ':count Undecided' => ':count Indecisi',
  'Participants' => 'Partecipanti',
);
