<?php

return [
    'Participants' => 'Osallistujat',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
