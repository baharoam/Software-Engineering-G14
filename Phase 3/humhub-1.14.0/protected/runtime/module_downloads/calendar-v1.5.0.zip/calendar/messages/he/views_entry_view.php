<?php
return array (
  'Additional information' => '',
  'All' => 'הכל',
  'Attend' => '',
  'Decline' => 'דחה',
  'Filter' => '',
  'Maybe' => '',
  'Participants' => '',
  'You are invited, please select your role:' => '',
);
