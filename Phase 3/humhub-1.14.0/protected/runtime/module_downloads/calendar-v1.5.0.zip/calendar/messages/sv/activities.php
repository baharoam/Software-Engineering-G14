<?php
return array (
  'Calendar: Invite' => 'Kalender: Bjud in',
  'Calendar: attend' => 'Kalender: delta',
  'Calendar: decline' => 'Kalender: avvisa',
  'Calendar: maybe' => 'Kalender: kanske',
  'Whenever someone declines to participate in an event.' => 'När någon avstår från att delta i ett evenemang.',
  'Whenever someone invites to participate in an event.' => 'När någon bjuder in att delta i ett evenemang.',
  'Whenever someone may be participating in an event.' => 'Närhelst någon kan delta i ett evenemang.',
  'Whenever someone participates in an event.' => 'När någon deltar i ett evenemang.',
);
