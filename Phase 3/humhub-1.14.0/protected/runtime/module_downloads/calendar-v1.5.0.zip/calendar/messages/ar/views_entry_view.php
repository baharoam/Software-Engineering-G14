<?php
return array (
  'Additional information' => '',
  'All' => 'الكل',
  'Attend' => '',
  'Decline' => 'رفض',
  'Filter' => 'تصفية',
  'Maybe' => '',
  'Participants' => '',
  'You are invited, please select your role:' => '',
);
