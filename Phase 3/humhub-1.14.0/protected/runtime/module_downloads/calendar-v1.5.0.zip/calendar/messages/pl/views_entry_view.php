<?php
return array (
  'Additional information' => 'Dodatkowe informacje',
  'All' => 'Wszystko',
  'Attend' => 'Wezmę udział',
  'Decline' => 'Odrzuć',
  'Filter' => 'Filtr',
  'Maybe' => 'Może',
  'Participants' => 'Uczestnicy',
  'You are invited, please select your role:' => '',
);
