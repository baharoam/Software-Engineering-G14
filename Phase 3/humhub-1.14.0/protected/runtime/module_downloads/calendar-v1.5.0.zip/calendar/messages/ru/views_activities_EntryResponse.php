<?php

return [
    '%displayName% cannot attend %contentTitle%.' => '',
    '%displayName% is attending %contentTitle%.' => '',
    '%displayName% is invited to %contentTitle%.' => '',
    '%displayName% might be attending %contentTitle%.' => '',
];
