<?php
return array (
  'Calendars' => '',
  'Defaults' => 'Standarder',
  'Event Types' => '',
  'Menu' => 'Menu',
  'Snippet' => '',
);
