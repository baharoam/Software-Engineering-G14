<?php

return [
    'Participants' => 'Deltagere',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
