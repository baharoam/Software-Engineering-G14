<?php
return array (
  'Additional information' => '',
  'All' => 'Alle',
  'Attend' => 'Deltag',
  'Decline' => 'Afslå',
  'Filter' => 'Filter',
  'Maybe' => 'Måske',
  'Participants' => 'Deltagere',
  'You are invited, please select your role:' => '',
);
