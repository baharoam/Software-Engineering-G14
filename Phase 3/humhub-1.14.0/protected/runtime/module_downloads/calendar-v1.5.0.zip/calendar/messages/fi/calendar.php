<?php
return array (
  'Day' => '',
  'List' => 'Lista',
  'Month' => '',
  'Today' => 'Tänään',
  'Week' => '',
  'Year' => '',
);
