<?php
return array (
  'Calendars' => '',
  'Defaults' => '默认',
  'Event Types' => '',
  'Menu' => '菜单',
  'Snippet' => '',
);
