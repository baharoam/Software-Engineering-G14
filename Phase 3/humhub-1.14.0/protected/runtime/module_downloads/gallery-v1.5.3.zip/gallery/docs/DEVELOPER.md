# Development

## Setup

Grunt is only used to build the stylesheets, if you don't plan on updating the styles you don't need to do these steps.

1. Check out the project
2. Run `npm install` to have Grunt ready

## Edit and Build Styles

To update the css documents, edit the `resources/css/gallery.less` file.  Then run `npm run build`.
