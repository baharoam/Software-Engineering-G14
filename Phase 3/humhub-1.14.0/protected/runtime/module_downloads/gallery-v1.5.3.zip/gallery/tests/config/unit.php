<?php
/**
 * Here you can overwrite your functional humhub config. The default config resiedes in @humhubTests/codeception/config/config.php
 */
return [];
